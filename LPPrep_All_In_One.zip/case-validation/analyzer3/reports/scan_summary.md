# scan_summary.md
Gerado em: 2025-10-04 22:04

Este resumo será preenchido de forma completa quando o analyzer3 rodar com `--validate` no repositório que contém `src/data`.
