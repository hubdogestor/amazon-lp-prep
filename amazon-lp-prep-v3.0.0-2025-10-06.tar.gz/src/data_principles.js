// src/data_principles.js
// Consolidates leadership principles data from organized folder structure

import consolidatedPrinciples from "./data/consolidatedPrinciples.js";

const principlesData = consolidatedPrinciples;

export default principlesData;
