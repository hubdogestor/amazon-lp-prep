// Case 3 - deliver_results
const case_3 = {
  id: "sicredi-fraud-reduction",
  title: "Fundei o Mecanismo Anti-Fraude que Cortou Perdas em 46% em 5 Meses",
  title_pt: "Fundei o Mecanismo Anti-Fraude que Cortou Perdas em 46% em 5 Meses",
  title_en: "Built the Anti-Fraud Mechanism that Cut Losses 46% in 5 Months",
  company: "Sicredi Woop",
  period: "01/2020-05/2020",
  isTopCase: false,
  isGoodCase: true,
  pt: {
    s: `Em dezembro de 2019 o Woop registrou recorde negativo: R$ 420k em perdas de onboarding fraudulento (217% acima da media), NPS de entrada despencando para 29 e 3.200 novos clientes bloqueados por engano. Cinco analistas reagiam manualmente, sem mecanismo de priorizacao e sob pressao da diretoria juridica para cortar aprovacoes ate a chegada de um modelo de IA que levaria 6 meses.`,
    t: `Eu assumi ownership integral. Prometi ao CEO reduzir perdas em pelo menos 30% em ate 5 meses, manter falsos positivos abaixo de 2% e reconquistar NPS de onboarding acima de 55 sem esperar o novo modelo preditivo.`,
    a: `Eu ataquei os dois inputs que moviam o resultado: deteccao e tempo de resposta. (1) Deteccao: mergulhei 72 horas no SQL analisando 5.137 tentativas e cruzei onboarding, device e KYC; a descoberta foi que 67% dos golpes vinham de documentos sintéticos criados nas ultimas 48h. Em uma semana escrevi 7 regras heuristicas em Python (idade X documento, OCR vs selfie, cluster de IP) que bloquearam 38% das tentativas ja no piloto. (2) Tempo de resposta: criei uma war room anti-fraude com risco, produto e engenharia; estipulei daily de 20 minutos, dashboard Datadog com deteccao, perdas por faixa e fila de revisao. Cada sinal amarelo acionava runbook em ate 2 horas. Quando os fraudadores migraram para deepfake de video, eu condensei as evidencias em 12 horas, consegui waiver do juridico para prova de vida ativa (piscar + comando de voz) e publiquei patch em 36 horas, derrubando 85% do novo vetor. (3) Clientes: para recuperar confianca, liguei pessoalmente para 30 microempresarios bloqueados e redesenhei fluxo de contestacao para 6 passos com SLA de 4 horas. Programei notificacao proativa no app explicando bloqueio e reprocesso.`,
    r: `Em cinco meses as perdas cairam de R$ 420k para R$ 226k (-46%), superando a meta. O tempo medio de resposta a novo padrao caiu de 21 dias para 18 horas (-96%), falsos positivos permaneceram em 1,6% e o NPS de onboarding subiu de 29 para 63 (+34 pontos). Recuperamos R$ 1,9M em receita anualizada por aprovar clientes legitimos que antes desistiam. O mecanismo virou playbook corporativo e foi replicado em mais tres unidades (cartao, credito rural, seguros).`,
    l: `Aprendi que entregar resultado sob ataque exige tratar dados, resposta e experiencia do cliente como a mesma linha critica. Hoje nunca encerro uma crise sem garantir heuristicas ativadas, war room rodando e jornada de contestacao transparente; essa combinacao virou mecanismo padrao onde opero pagamentos.`
  },
  en: {
    s: `In December 2019 Woop hit a record low: R$420K in fraudulent onboarding losses (217% above normal), entry NPS dropped to 29, and 3,200 new members were wrongly blocked. Five analysts reacted manually, legal pressure pushed for blanket denials, and the planned AI model was six months away.`,
    t: `I took full ownership and promised the CEO I would cut losses by at least 30% within five months, keep false positives below 2%, and bring onboarding NPS back above 55 without waiting for the new ML model.`,
    a: `I attacked the two inputs driving the outcome: detection and response time. (1) Detection: I spent 72 hours in SQL analyzing 5,137 attempts, joining onboarding, device, and KYC tables; 67% of attacks used synthetic documents created within 48 hours. In one week I wrote seven Python heuristics (age vs document, OCR/selfie delta, IP clusters) that blocked 38% of attempts in pilot. (2) Response time: I created an anti-fraud war room with risk, product, and engineering; ran 20-minute dailies, launched a Datadog dashboard with detection, losses by band, and review queue, and tied alerts to a two-hour runbook. When fraudsters shifted to video deepfakes I condensed evidence in 12 hours, obtained legal approval for active liveness (blink + voice command), and shipped a patch in 36 hours, shutting down 85% of the new vector. (3) Customer trust: I personally called 30 blocked microbusiness owners, redesigned the dispute flow to six steps with a four-hour SLA, and launched in-app notifications explaining the block and reproccess.`,
    r: `Within five months losses dropped from R$420K to R$226K (-46%), beating the goal. Average response to new patterns fell from 21 days to 18 hours (-96%), false positives stayed at 1.6%, and onboarding NPS climbed from 29 to 63 (+34 points). We recovered R$1.9M in annualized revenue by approving legitimate clients who previously quit. The mechanism became the corporate playbook and rolled out to three other units (cards, rural credit, insurance).`,
    l: `I learned that delivering results under attack means treating data, response, and customer experience as one critical path. I never close a crisis without heuristics live, a war room running, and a transparent dispute journey; that combo is now the default mechanism in every payments operation I lead.`
  },
  fups: [
    {
      "q": "Como voce priorizou quais regras heuristicas escrever primeiro?",
      "a": "Classifiquei 5.137 tentativas por perda potencial, foco em top 20% dos ataques; escrevi regras para cruzar idade vs documento, checksum de OCR e historico de IP." ,
      "q_en": "How did you prioritize which heuristics to code first?",
      "a_en": "I ranked 5,137 attempts by loss exposure, focused on the top 20% patterns, and coded rules for age/document mismatch, OCR checksum, and IP history." 
    },
    {
      "q": "Qual governanca voce criou para aprovar novas regras em 24h?",
      "a": "Montei triade Risco-Produto-Engenharia, criei checklist de impacto, execucao em 2h e revisao juridica asincrona; somente eu liberava producao." ,
      "q_en": "What governance let you approve new rules in 24 hours?",
      "a_en": "I set a Risk-Product-Engineering triad, built an impact checklist, executed changes in two hours with asynchronous legal review, and I gave the final production go." 
    },
    {
      "q": "Como mensurou a recuperacao de receita?",
      "a": "Comparei coorte de clientes liberados apos heuristicas com baseline Q3/2019: ticket medio R$ 58, LTV 18 meses, resultando em R$ 1,9M anualizado." ,
      "q_en": "How did you measure recovered revenue?",
      "a_en": "I compared the cohort of customers approved after the heuristics with the Q3/2019 baseline: average ticket R$58, 18-month LTV, totaling R$1.9M annualized." 
    },
    {
      "q": "Que indicadores voce acompanhou diariamente na war room?",
      "a": "Tentativas bloqueadas, perdas por vetor, tempo de resposta, falsos positivos, NPS de onboarding e fila de contestacao." ,
      "q_en": "Which indicators did you track daily in the war room?",
      "a_en": "Blocked attempts, losses by vector, response time, false positives, onboarding NPS, and dispute queue backlog." 
    },
    {
      "q": "Como voce conteve o protesto do juridico quanto a prova de vida ativa?",
      "a": "Submeti parecer com base LGPD, demonstrei que 92% das tentativas vinham de persona unica e inseri auditoria quinzenal com log criptografado." ,
      "q_en": "How did you address legal's pushback on active liveness?",
      "a_en": "I provided an LGPD-based legal memo, showed that 92% of attempts originated from one persona, and added a biweekly audit with encrypted logs." 
    },
    {
      "q": "Qual a estrutura do runbook de 2 horas?",
      "a": "Defini 6 passos: detectar, classificar, validar, acao no motor, comunicacao cliente, retroalimentacao; cada passo tinha owner e SLA." ,
      "q_en": "What was inside your two-hour runbook?",
      "a_en": "Six steps: detect, classify, validate, deploy rule, notify customer, feed back to analytics; each step with an owner and SLA." 
    },
    {
      "q": "Como voce manteve falsos positivos em 1,6% mesmo endurecendo regras?",
      "a": "Implementei amostragem diaria de 300 casos, rodei champion-challenger e reverti qualquer regra com impacto >0,3 p.p. em FP." ,
      "q_en": "How did you keep false positives at 1.6% while tightening rules?",
      "a_en": "I sampled 300 cases daily, ran champion-challenger tests, and rolled back any rule that raised false positives above 0.3 p.p." 
    },
    {
      "q": "Que aprendizado voce compartilhou com as outras unidades?",
      "a": "Documentei heuristicas, matriz de risco e roteiro de comunicacao em playbook de 18 paginas e treinei squads de cartao, rural e seguros." ,
      "q_en": "What did you pass to the other business units?",
      "a_en": "I documented heuristics, risk matrix, and communication scripts in an 18-page playbook and trained the card, rural, and insurance squads." 
    },
    {
      "q": "Como voce lidou com clientes bloqueados indevidamente?",
      "a": "Criei canal direto comigo, resposta em 4h, credito de R$ 50 em tarifa e acompanhamento do gerente de conta por 30 dias." ,
      "q_en": "How did you handle wrongly blocked customers?",
      "a_en": "I opened a direct line with me, set a four-hour response, offered a R$50 fee credit, and assigned account-manager follow-up for 30 days." 
    },
    {
      "q": "Qual a maior decisao de trade-off que voce tomou no projeto?",
      "a": "Priorizei heuristicas rapidas em vez de treinar modelo de IA de 12 semanas; aceitei precisao menor no inicio para gerar folego financeiro imediato." ,
      "q_en": "What was the toughest trade-off you made?",
      "a_en": "I chose fast heuristics over a 12-week ML model, accepting slightly lower accuracy early on to generate immediate financial relief." 
    }
  ]
};

export default case_3;
