// Case 3 - earn_trust
const case_3 = {
  id: "bradesco-partner-recovery",
  title: "Reconquistei parceiro chave com plano de saldo garantido em 30 dias",
  title_pt: "Reconquistei parceiro chave com plano de saldo garantido em 30 dias",
  title_en: "Won back key partner with 30-day guaranteed settlement plan",
  company: "Bradesco Payments",
  period: "09/2017-01/2018",
  isTopCase: false,
  isGoodCase: false,
  pt: {
    s: `Um marketplace que respondia por 18% do nosso TPV suspendeu operacoes em setembro de 2022 depois que atrasamos tres ciclos de liquidacao D+1. R$ 420M ficaram parados, 8.700 sellers reclamaram e o parceiro publicou notinha dizendo que migraria para concorrente. O CEO exigiu que eu abrisse renegociacao com garantia pessoal de que o problema nao voltaria.`,
    t: `Eu assumi como single-threaded owner. Prometi normalizar o backlog em 10 dias, reduzir variacao de saldo a menos de 0,2% e assinar um acordo de nivel de confianca com clausulas que eu mesmo supervisionaria.`,
    a: `Primeiro eu tracei a raiz: um descompasso entre agenda de liquidez e janelas de recompra. Eu sentei com tesouraria e impus um buffer de R$ 80M sob meu controle, com previsao de caixa atualizada a cada 4 horas. Enfrentei a resistencia do diretor financeiro que nao queria imobilizar capital; eu provei que perder o parceiro destruiria R$ 52M em receita anual e aceitei reduzir meu budget de marketing em 18% para compensar. Segundo, criei o mecanismo "Saldo Garantido 7h": todo seller receberia extrato assinado por mim as 7h mostrando saldo futuro, repasse e eventual ajuste. Terceiro, fui ao parceiro, apresentei dados, reconheci publicamente a falha e pedi 30 dias para estabilizar. Eu aceitei auditoria externa deles, abri acesso ao meu dashboard e fiz stand-up diario com o CFO do marketplace. Quarto, implantei um monitor de confianca com 12 indicadores (SLA, tickets, saldo, NPS) e enviei carta semanal com resumo, incidentes e plano.`,
    r: `Em 9 dias eu zerei o backlog de R$ 420M, zerei tickets acima de 24h, e o NPS do parceiro voltou de 18 para 63 em seis semanas. A variacao de saldo ficou em 0,08%, o churn de sellers caiu 3,9 p.p., e o marketplace assinou renovacao de contrato por mais dois anos. O executivo que me cobrou inicialmente passou a me convidar para revisar novos produtos conjuntos.`,
    l: `Eu aprendi que earn trust com parceiro so acontece quando voce compromete capital proprio e comunica a verdade antes do boato. Mostrar saldo futuro assinado por mim mudou o relacionamento: hoje qualquer parceiro recebe a carta diaria mesmo sem incidente.`,
  },
  en: {
    s: `A marketplace responsible for 18% of our TPV halted operations in September 2022 after we missed three D+1 settlement cycles. BRL 420M remained frozen, 8,700 sellers complained, and the partner announced they would migrate to a competitor. The CEO demanded I renegotiate with personal assurance the issue would not recur.`,
    t: `I acted as the single-threaded owner. I committed to clear the backlog within ten days, keep balance variance under 0.2%, and sign a trust-level agreement with clauses I would personally supervise.`,
    a: `I diagnosed the root cause: a mismatch between liquidity schedule and buyback windows. I sat with treasury and imposed an BRL 80M buffer under my control with cash forecasts refreshed every four hours. The finance director resisted the capital lock; I proved losing the partner would destroy BRL 52M in annual revenue and agreed to cut my marketing budget by 18% to offset. Next I created the "7 a.m. Guaranteed Balance" mechanism: every seller received a statement signed by me at 7 a.m. showing future balance, payout, and any adjustment. I visited the partner, presented the data, owned the error publicly, and asked for 30 days to stabilize. I accepted their external audit, opened dashboard access, and ran a daily stand-up with the partner CFO. Finally I implemented a trust monitor with twelve indicators (SLA, tickets, balance, NPS) and sent a weekly letter summarizing incidents and plans.`,
    r: `Within nine days I cleared the BRL 420M backlog, eliminated tickets older than 24 hours, and the partner NPS rose from 18 to 63 within six weeks. Balance variance stayed at 0.08%, seller churn fell 3.9 p.p., and the marketplace renewed the contract for two years. The executive who challenged me now invites me to co-design joint products.`,
    l: `I learned that earning a partner's trust requires putting your own capital on the line and telling the truth before rumors spread. Sending future balance statements signed by me transformed the relationship; today every partner receives the daily letter even when no incident occurs.`,
  },
  fups: [
    { q: "Como voce definiu o buffer de R$ 80M?", a: "Eu calculei desvio padrao das liquidacoes em 18 meses e multipliquei por 2,1 para cobrir picos.", q_en: "How did you define the BRL 80M buffer?", a_en: "I used 18 months of settlement variance and multiplied the standard deviation by 2.1 to cover peaks." },
    { q: "Que informacoes iam no extrato das 7h?", a: "Saldo futuro, reservas, creditos agendados, ajustes e telefone direto meu.", q_en: "What did the 7 a.m. statement include?", a_en: "Future balance, reserves, scheduled credits, adjustments, and my direct phone number." },
    { q: "Como voce acompanhou tickets?", a: "Eu criei heatmap diario com idade dos tickets e forcei squads a baixar para menos de 12 horas.", q_en: "How did you track tickets?", a_en: "I built a daily heatmap showing ticket age and forced squads to keep them under 12 hours." },
    { q: "Qual foi o maior risco da auditoria externa?", a: "Expor logs sensiveis; eu criei sala segura e revisao conjunta para manter compliance.", q_en: "What was the biggest risk in the external audit?", a_en: "Sensitive logs exposure; I set up a secure room and joint review to preserve compliance." },
    { q: "Que custodias financeiras voce negociou?", a: "Clausula de piso de R$ 50M, opcao de saque emergencial e multa regressiva por atraso.", q_en: "Which financial safeguards did you negotiate?", a_en: "A BRL 50M floor, emergency withdrawal option, and declining penalty per delay." },
    { q: "Como voce mediu confianca do parceiro?", a: "Score semanal de transparencia, numero de escalacoes (caiu de 7 para 0) e NPS.", q_en: "How did you measure partner trust?", a_en: "Weekly transparency score, escalation count (down from seven to zero), and NPS." },
    { q: "Qual trade-off voce assumiu internamente?", a: "Cortei 18% do budget de marketing e pausei dois experimentos por tres meses.", q_en: "What internal trade-off did you accept?", a_en: "I cut 18% of the marketing budget and paused two experiments for three months." },
    { q: "Como voce garantiu que o problema nao volta?", a: "Instalei alerta automatico quando variacao passa de 0,15% e autorizo liberacao extra pessoalmente.", q_en: "How did you prevent recurrence?", a_en: "I set automatic alerts when variance exceeds 0.15% and personally approve extra releases." },
    { q: "Qual impacto nos vendedores finais?", a: "Saldo medio recebia em 23 horas antes, agora em 6 horas; chargebacks caram 21%.", q_en: "What was the impact on end sellers?", a_en: "Average balance arrived in 23 hours before, now in six hours; chargebacks fell 21%." },
    { q: "Como voce replicou o aprendizado?", a: "Implementei carta de saldo em outros quatro parceiros que somam R$ 1,2B de TPV.", q_en: "How did you replicate the learning?", a_en: "I deployed the balance letter across four other partners totaling BRL 1.2B TPV." }
  ]
};

export default case_3;
