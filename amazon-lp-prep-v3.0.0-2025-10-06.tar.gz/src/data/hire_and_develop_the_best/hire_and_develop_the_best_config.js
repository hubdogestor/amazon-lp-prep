// Configurações do LP - hire_and_develop_the_best
const hire_and_develop_the_best_config = {
  principle: {
    title: "Contratar e Desenvolver os Melhores",
    title_en: "Hire and Develop the Best",
    description: `Os líderes elevam a barra de desempenho a cada contratação e promoção. Eles reconhecem talentos excepcionais e os movem voluntariamente por toda a organização.`,
    description_en: `Leaders raise the performance bar with every hire and promotion. They recognize exceptional talent, and willingly move them throughout the organization.`,
    icon: "🌟"
  },
  id: "hire_and_develop_the_best",
  name: "Contratar e Desenvolver os Melhores"
};

export default hire_and_develop_the_best_config;
