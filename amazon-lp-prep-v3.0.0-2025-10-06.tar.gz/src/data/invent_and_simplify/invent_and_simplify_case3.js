// Case 3 - invent_and_simplify
const case_3 = {
  id: "unimed-ai-authorization",
  title: "Inventei IA de Autorizacao Medica que Simplificou Processo de 5 Dias para 9 Horas (82% Automacao)",
  title_pt: "Inventei IA de Autorizacao Medica que Simplificou Processo de 5 Dias para 9 Horas (82% Automacao)",
  title_en: "Invented Medical Authorization AI that Simplified 5-Day Process to 9 Hours (82% Automation)",
  company: "Unimed",
  period: "01/2023-10/2023",
  isTopCase: true,
  isGoodCase: false,
  pt: {
    s: `Eu fui chamado quando 1.120 solicitacoes medicas por dia enfrentavam 5,1 dias de espera e o NPS caiu de 48 para 19 em tres meses. Os oito maiores hospitais parceiros ameaçaram migrar 22 mil vidas porque pacientes onco estavam perdendo janela clinica de 48 horas. Em 36 horas eu entrei nas salas de recuperacao, conversei com 14 pacientes e gravei que 64% da dor vinha da confirmacao de cobertura, nao do laudo. Tambem identifiquei que 71% dos 3.400 contatos semanais no call center eram pedidos de urgencia sem tracking.`,
    t: `Eu assumi ownership total e defini meta clara: automatizar 80% das decisoes ate out/23 sem aumentar risco clinico e reduzir o SLA critico para 12 horas. Eu comuniquei pessoalmente ao conselho medico que eu assinaria cada regra de negocio implantada e reportaria semanalmente cada excecao.`,
    a: `Primeiro, eu construí em duas semanas um mapa de jornada com 19 pontos de contato, priorizando onde o paciente ficava sem resposta. Para gerar fibra de cliente, eu criei o indicador "tempo de angustia" que mede horas entre pedido e retorno; compartilhei diariamente com as diretorias hospitalares. Segundo, eu estruturei o modelo de IA usando 220 mil autorizacoes historicas e 58 features clinicas, mas removi 11 variaveis sensiveis que geravam vies; eu mesmo reescrevi as regras de cobertura para cirurgias de alto risco. Terceiro, enfrentei resistencia do comite de auditoria que exigia dupla checagem humana: eu provei com um experimento A/B que o modelo acerta 95,2% e que a revisao manual adicionava 18 horas sem ganho clinico, entao negociei limites dinamicos por valor e por CID. Tambem gerei conflito com TI ao bypassar o legado AS/400; eu criei uma camada de API em Python e garanti compliance com LGPD criptografando 17 campos sensiveis. Por fim, implementei um Painel de Confianca que mostra as tres variaveis chave de cada decisao, e eu mesmo rodei 32 sessões de alinhamento com medicos e ouvidoria.`,
    r: `Em 90 dias eu automatizei 82% das autorizacoes, reduzi o SLA medio para 9 horas e zerei a fila de oncologia criticamente atrasada. O tempo de angustia despencou 78%, o NPS subiu para 67 e as queixas formalizadas na ANS caíram 63%. Economizamos R$ 2,4M ao ano em horas extras e reinvesti R$ 600k em teleconsulta rapida para casos borderline. Os hospitais suspenderam a ameaca de migração e renovaram contratos por mais dois anos. A expansao levou o mecanismo para mais quatro linhas de cuidado, mantendo 0,8% de override humano e zero eventos clinicos.`,
    l: `Eu aprendi que inventar com simplicidade exige defender o paciente em todas as salas. O indicador de angustia virou meu gatilho para priorizar tech de alto impacto: quando escuto a voz do beneficiario, eu consigo negociar com auditores, TI e conselhos clinicos sem perder velocidade. Em pagamentos, uso a mesma logica para reduzir onboarding de comerciantes: medir horas de espera, eliminar etapas duplicadas e deixar a IA explicavel desde o primeiro dia.`,
  },
  en: {
    s: `I was called in when 1,120 medical requests per day faced a 5.1-day wait and NPS fell from 48 to 19 in three months. The eight largest partner hospitals threatened to move 22 thousand lives because oncology patients were missing a 48-hour clinical window. Within 36 hours I sat in recovery rooms, spoke with 14 patients, and recorded that 64% of the pain came from coverage confirmation, not from the medical report. I also identified that 71% of the 3,400 weekly contact-center calls were urgent requests with no tracking.`,
    t: `I took full ownership and set a clear goal: automate 80% of decisions by Oct/23 without increasing clinical risk and cut the critical SLA to 12 hours. I personally told the medical board that I would sign every business rule deployed and report each exception weekly.`,
    a: `First, I built a two-week journey map with 19 touchpoints, prioritizing where patients were left without answers. To anchor customer obsession, I created the "distress time" indicator measuring hours between request and response; I shared it daily with hospital directors. Second, I structured the AI model using 220 thousand historical authorizations and 58 clinical features, but removed 11 sensitive variables that introduced bias; I personally rewrote coverage rules for high-risk surgeries. Third, I faced resistance from the audit committee demanding double human review: I proved through an A/B experiment that the model hit 95.2% accuracy and manual review added 18 hours with no clinical benefit, so I negotiated dynamic thresholds by claim value and ICD code. I also clashed with IT when bypassing the AS/400 legacy; I built a Python API layer and guaranteed LGPD compliance by encrypting 17 sensitive fields. Finally, I implemented a Confidence Panel showing the top three drivers for each decision and led 32 alignment sessions with physicians and the ombudsman.`,
    r: `In 90 days I automated 82% of authorizations, reduced average SLA to 9 hours, and cleared the oncology backlog. Distress time dropped 78%, NPS rose to 67, and formal complaints to the regulator fell 63%. We saved R$ 2.4M per year in overtime and I reinvested R$ 600k in rapid teleconsultation for borderline cases. Hospitals withdrew the migration threat and renewed contracts for two more years. Expansion carried the mechanism to four additional care lines while keeping human override at 0.8% and zero clinical incidents.`,
    l: `I learned that inventing with simplicity means defending the patient in every room. The distress indicator became my trigger to prioritize high-impact tech: when I amplify the beneficiary's voice, I can negotiate with auditors, IT, and medical boards without losing speed. In payments I apply the same logic to merchant onboarding: measure waiting hours, remove duplicate steps, and make AI explainable from day one.`,
  },
  fups: [
    {
      q: "Como voce selecionou os 58 atributos do modelo?",
      a: "Eu fiz feature store com base em 12 entrevistas com auditores e testei 94 variaveis; mantive as 58 com ganho de informacao acima de 0,02 e que tinham correlacao clinica validada pelo board.",
      q_en: "How did you select the 58 model attributes?",
      a_en: "I built the feature store from 12 auditor interviews and tested 94 variables; I kept the 58 with information gain above 0.02 and clinically validated by the board."
    },
    {
      q: "Qual foi o maior sinal de customer obsession na execucao?",
      a: "Eu fiz todas as dailies abrindo com depoimentos dos pacientes, publiquei o indicador de angustia na intranet e acompanhei pessoalmente cada caso onco ate a alta.",
      q_en: "What was the strongest customer-obsession signal during execution?",
      a_en: "I opened every daily standup with patient recordings, published the distress indicator on the intranet, and personally followed each oncology case until discharge."
    },
    {
      q: "Como voce tratou o risco de viés algoritmico?",
      a: "Eu rodei fairness metrics por genero e faixa etaria, cortei 11 variaveis de renda e ajustei pesos ate reduzir a diferenca de aprovacao para menos de 2 p.p. entre grupos.",
      q_en: "How did you deal with algorithmic bias risk?",
      a_en: "I ran fairness metrics by gender and age, removed 11 income-related variables, and tuned weights until approval gap stayed below 2 p.p. across groups."
    },
    {
      q: "Como voce mediu impacto financeiro alem da economia de FTE?",
      a: "Eu cruzei base de sinistralidade e provei queda de 5,6% em reembolsos emergenciais e aumento de 2,1% em receita de planos premium devido a renovacoes antecipadas.",
      q_en: "How did you measure financial impact beyond FTE savings?",
      a_en: "I connected claims data and proved a 5.6% drop in emergency reimbursements plus a 2.1% premium-plan revenue uplift from early renewals."
    },
    {
      q: "Qual conflito voce teve com o conselho medico e como resolveu?",
      a: "Eles queriam voto de minerva em cada negativa automatica; eu propus limite dinamico por CID e defendi pessoalmente cada caso acima de R$ 8k em reuniao semanal.",
      q_en: "What conflict did you face with the medical board and how did you resolve it?",
      a_en: "They wanted veto power on every automatic denial; I proposed a dynamic threshold per ICD and personally defended each case above R$ 8k in the weekly meeting."
    },
    {
      q: "Como voce garantiu explainability para reguladores?",
      a: "Eu integrei o Painel de Confianca com logs que mostram pesos do modelo, gerei relatórios mensais para ANS e capturei assinatura digital de todos os ajustes.",
      q_en: "How did you guarantee explainability to regulators?",
      a_en: "I integrated the Confidence Panel with model-weight logs, produced monthly reports for the regulator, and captured digital signatures for every adjustment."
    },
    {
      q: "Que testes voce fez antes de escalar para 82%?",
      a: "Eu conduzi piloto de 30 dias com duas linhas de cuidado, acompanhei retrospectivas diarias e so expandi quando o falso positivo ficou abaixo de 1,5%.",
      q_en: "What tests did you run before scaling to 82%?",
      a_en: "I ran a 30-day pilot covering two care lines, tracked daily retrospectives, and only expanded once false positives stayed under 1.5%."
    },
    {
      q: "Como voce manteve o ratio EU:NOS acima de 3:1?",
      a: "Eu centralizei aprovacoes, mantive meu nome em cada decisao critica e registrei no painel quem aprovou, reforcando que as escolhas chave eram minhas.",
      q_en: "How did you keep the I:we ratio above 3:1?",
      a_en: "I centralized approvals, kept my name on every critical decision, and logged ownership in the panel to reinforce that the decisive calls were mine."
    },
    {
      q: "Qual proximo mecanismo voce ativou com o aprendizado?",
      a: "Eu criei squad para reembolso odontologico usando o mesmo painel e o indicador de angustia, reduzindo SLA de 6 dias para 26 horas em 45 dias.",
      q_en: "Which next mechanism did you activate using the learning?",
      a_en: "I launched a squad for dental reimbursements using the same panel and distress indicator, cutting SLA from 6 days to 26 hours within 45 days."
    },
    {
      q: "Como isso se conecta a pagamentos e fintech?",
      a: "Eu levo o conceito de explainability e do indicador de angustia para underwriting de sellers, deixando claro pro cliente por que a IA aprovou ou nao e devolvendo resposta em menos de 2 horas.",
      q_en: "How does this connect to payments and fintech?",
      a_en: "I bring the explainability concept and the distress indicator to seller underwriting, making it clear why AI approved or not and returning decisions in under two hours."
    }
  ]
};

export default case_3;
