// Case 4 - invent_and_simplify
const case_4 = {
  id: "unimed-open-innovation",
  title: "Inventei plataforma aberta com LP SaaS que reduziu ciclo de inovacao em 68%",
  title_pt: "Inventei plataforma aberta com LP SaaS que reduziu ciclo de inovacao em 68%",
  title_en: "Invented open platform with SaaS LP that cut innovation cycle by 68%",
  company: "Unimed",
  period: "02/2022-12/2023",
  isTopCase: false,
  isGoodCase: true,
  pt: {
    s: `Eu encontrei o ecossistema de inovacao da Unimed travado: 47 projetos internos demoravam em media 21 meses para virar MVP, queimando R$ 2,1M cada um, e 63% eram cancelados sem tocar paciente algum. Doze startups parceiras tinham abandonado os pilotos porque levavam 140 dias para assinar NDA. Enquanto isso, 52 mil medicos cooperados reclamavam da burocracia e o NPS das solucoes digitais caiu de 55 para 28. Eu visitei oito cooperativas regionais em duas semanas e ouvi de gestores e pacientes que a dor real era a falta de solucoes simples para telemonitorar cronicos.`,
    t: `Eu decidi ser owner de ponta a ponta e tracei a meta de lancar um hub aberto que gerasse MVP em seis meses, priorizando dores validadas por pacientes. Eu me comprometi a cortar o ciclo de aprovacao em 70% e entregar pelo menos tres solucoes com NPS acima de 60 ate o fim de 2023.`,
    a: `Primeiro, eu coletei dados de 1.260 horas de backlog e provei que 41% do tempo era gasto em comites. Eu eliminei quatro camadas de aprovacao criando o mecanismo "Fast-Track Klin" onde eu, como sponsor, assinava contrato marco com startups em 10 dias e acionava um sandbox juridico. Segundo, eu construi uma tese de investimento baseada em voice of customer: rodei 28 entrevistas com pacientes cronicos e analisei 180 mil mensagens da ouvidoria; priorizei solucoes de monitoramento remoto e adesao a terapias. Terceiro, enfrentei resistencia do conselho financeiro que temia exposure regulatorio; eu negociei um limite de R$ 15M com stop-loss por coorte e instalei OKRs vinculando retorno clinico e payback de 18 meses. Tambem convenci lideres assistenciais reticentes organizando um "clinical demo day" onde cada startup apresentava resultados acompanhados por mim e por um medico patrocinador. Por fim, eu implantei a Plataforma de Inovacao aberta usando uma combinacao de APIs FHIR e um repositório de dados anonimizados que eu normalizei em quatro semanas.`,
    r: `Em dez meses eu lancei quatro solucoes priorizadas pela voz do paciente: telemonitoramento de insuficiencia cardiaca, adherence-as-a-service para oncologia, analytics de fila eletiva e triagem digital de saude mental. O ciclo medio caiu de 21 para 6,7 meses (68% de reducao), o custo de desenvolvimento baixou 44% e o NPS das solucoes passou para 64 em 90 dias. Gerei R$ 36M em economia projetada, reduzi readmissoes cardiacas em 19% e aumentei em 12 p.p. a adesao terapeutica em oncologia. O hub atraiu 96 startups, firmou 14 contratos ativos e ganhou selo ANS de inovacao responsavel.`,
    l: `Eu aprendi que simplicidade em inovacao corporativa so acontece quando alguem assume caneta unica para cortar burocracia e manter o paciente no centro da conversa. O Fast-Track Klin virou minha referencia para qualquer parceria fintech: contrato marco, voice of customer e sandbox legal que preserva velocidade sem comprometer compliance.`,
  },
  en: {
    s: `I found Unimed's innovation ecosystem paralyzed: 47 internal projects took 21 months on average to reach MVP, burning R$ 2.1M each, and 63% were cancelled without touching any patient. Twelve partner startups had abandoned pilots because NDAs took 140 days to sign. Meanwhile 52 thousand cooperative physicians complained about bureaucracy and the digital solutions' NPS fell from 55 to 28. I visited eight regional cooperatives in two weeks and heard from managers and patients that the true pain was the absence of simple tools to remotely monitor chronic conditions.`,
    t: `I chose to own end-to-end and set the goal to launch an open hub shipping MVPs in six months, prioritizing patient-validated pains. I committed to shorten approval cycles by 70% and deliver at least three solutions with NPS above 60 by the end of 2023.`,
    a: `First, I collected data from 1,260 hours of backlog and proved 41% of time was wasted in committees. I eliminated four approval layers by creating the "Fast-Track Klin" mechanism where I, as sponsor, signed master agreements with startups in ten days and activated a legal sandbox. Second, I built an investment thesis anchored on customer voice: I ran 28 interviews with chronic patients and analyzed 180 thousand ombudsman messages, prioritizing remote monitoring and therapy adherence solutions. Third, I faced resistance from the finance board fearing regulatory exposure; I negotiated a R$ 15M cap with cohort stop-loss and installed OKRs linking clinical return and 18-month payback. I also won over skeptical clinical leaders by organizing a "clinical demo day" where each startup presented results alongside me and a physician sponsor. Finally, I deployed the open innovation platform using a blend of FHIR APIs and a de-identified data repository that I normalized within four weeks.`,
    r: `In ten months I launched four patient-voice solutions: heart-failure telemonitoring, adherence-as-a-service for oncology, elective-surgery queue analytics, and digital mental-health triage. The average cycle dropped from 21 to 6.7 months (68% reduction), development cost fell 44%, and solution NPS climbed to 64 within 90 days. I generated R$ 36M in projected savings, reduced cardiac readmissions by 19%, and lifted oncology therapy adherence by 12 p.p. The hub attracted 96 startups, closed 14 active contracts, and earned the regulator's responsible-innovation seal.`,
    l: `I learned that simplicity in corporate innovation only happens when someone grabs a single pen to cut bureaucracy while keeping patients at the center. The Fast-Track Klin mechanism became my blueprint for any fintech partnership: master agreement, customer voice, and a legal sandbox that preserves speed without compromising compliance.`,
  },
  fups: [
    {
      q: "Como voce priorizou as dores dos pacientes na escolha das startups?",
      a: "Eu usei os 28 depth interviews e 180 mil registros da ouvidoria para criar um score de urgencia que pesava impacto clinico, frequencia e custo; as startups com score acima de 8 entraram na primeira onda.",
      q_en: "How did you prioritize patient pains when selecting startups?",
      a_en: "I combined the 28 depth interviews and 180 thousand ombudsman records into an urgency score weighing clinical impact, frequency, and cost; startups scoring above 8 joined wave one."
    },
    {
      q: "Qual resistencia mais dura voce enfrentou e como venceu?",
      a: "O conselho financeiro queria manter cinco aprovacoes sequenciais; eu levei analise mostrando 41% do tempo perdido e aceitei colocar stop-loss de R$ 15M com auditoria trimestral, assumindo responsabilidade pessoal pelas excecoes.",
      q_en: "What was the toughest resistance and how did you win?",
      a_en: "The finance board wanted five sequential approvals; I presented the 41% wasted-time analysis and accepted a R$ 15M stop-loss with quarterly audit, taking personal responsibility for exceptions."
    },
    {
      q: "Como voce garantiu compliance regulatorio no sandbox?",
      a: "Eu desenhei o sandbox com LGPD by design, criei contratos modulares revisados por mim e por um advogado dedicado e defini 22 controles obrigatorios monitorados via dashboard.",
      q_en: "How did you guarantee regulatory compliance inside the sandbox?",
      a_en: "I designed the sandbox LGPD-by-design, created modular contracts reviewed by me and a dedicated lawyer, and defined 22 mandatory controls monitored via dashboard."
    },
    {
      q: "Como voce mediu o impacto financeiro das startups?",
      a: "Eu cruzei dados de sinistralidade e call center, estimando economia de R$ 36M com base na reducao de readmissoes, menor uso de leitos e corte de consultas duplicadas.",
      q_en: "How did you measure the financial impact from the startups?",
      a_en: "I cross-referenced claims and call-center data, estimating R$ 36M in savings from fewer readmissions, reduced bed usage, and elimination of duplicate visits."
    },
    {
      q: "Qual mecanismo voce deixou para evitar retrocesso burocratico?",
      a: "Eu institucionalizei o comite Fast-Track com charter que me da voto qualificado, cadenciei reviews mensais e instalei scorecards publicos para todas as diretorias.",
      q_en: "What mechanism did you leave to prevent bureaucratic relapse?",
      a_en: "I institutionalized the Fast-Track committee with a charter granting me tie-breaking vote, scheduled monthly reviews, and published scorecards for every board."
    },
    {
      q: "Como voce assegurou ratio EU:NOS elevado?",
      a: "Eu assumi todas as negociacoes chave com startups, conduzi pessoalmente cada demo e registrei qual decisao eu tomei em ata, reforcando ownership individual.",
      q_en: "How did you keep I:we ratio high?",
      a_en: "I led every key negotiation with startups, personally ran each demo, and logged the decisions I made in the minutes to reinforce individual ownership."
    },
    {
      q: "Que experimentos voce abortou e por que?",
      a: "Eu encerrei duas provas de conceito em 30 dias porque nao atingiram 20% de adesao; comuniquei diretamente aos CEOs das startups e redirecionei budget para quem ja mostrava NPS acima de 60.",
      q_en: "Which experiments did you kill and why?",
      a_en: "I killed two proofs of concept within 30 days because they failed to reach 20% adoption; I told the startup CEOs directly and redirected budget to those already hitting NPS above 60."
    },
    {
      q: "Como voce engajou os medicos cooperados?",
      a: "Eu criei o clinical demo day com votacao, escolhi 15 lideres clinicos para co-patrocinar e garanti que cada caso de sucesso fosse compartilhado em boletins semanais.",
      q_en: "How did you engage cooperative physicians?",
      a_en: "I created the clinical demo day with voting, selected 15 clinical leaders as co-sponsors, and made sure each success case appeared in the weekly bulletins."
    },
    {
      q: "Quais metricas voce monitora para sustentar o hub?",
      a: "Eu acompanho time-to-MVP, NPS por solucao, payback, e um indice de risco regulatorio; mantenho gatilho que pausa onboarding se alguma startup exceder 10 incidentes de LGPD.",
      q_en: "Which metrics do you track to sustain the hub?",
      a_en: "I track time-to-MVP, solution NPS, payback, and a regulatory-risk index; I keep a trigger that pauses onboarding if any startup exceeds ten LGPD incidents."
    },
    {
      q: "Como esse mecanismo escala para pagamentos?",
      a: "Eu aplico o Fast-Track Klin em parcerias com fintechs: contrato marco, base de clientes priorizada por dor e sandbox legal que me permite testar compliance rapidamente.",
      q_en: "How does this mechanism scale into payments?",
      a_en: "I apply the Fast-Track Klin approach to fintech partnerships: master agreement, customer-pain based prioritization, and a legal sandbox that lets me validate compliance fast."
    }
  ]
};

export default case_4;
