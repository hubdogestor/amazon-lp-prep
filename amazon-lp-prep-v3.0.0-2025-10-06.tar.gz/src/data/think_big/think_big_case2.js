﻿// Case 2 - think_big
const case_2 = {
  id: "unimed-ecosystem-transformation",
  title: "Transformação da Unimed em Ecossistema de Saúde Digital",
  title_pt: "Liderança da Iniciativa para Transformar a Unimed de uma Seguradora para um Ecossistema de Saúde Digital",
  title_en: "Leading Unimed's Transformation from Insurance to Digital Health Ecosystem",
  company: "Unimed",
  period: "07/2021-02/2024",
  isTopCase: true,
  isGoodCase: false,
  pt: {
    s: `Situação — Em 2021, eu analisava a curva de churn da Unimed e vi um padrão alarmante: clientes multicanal migravam 2,4x mais para healthtechs full service. O conselho queria reagir com bundles promocionais no plano tradicional. Eu provoquei: se eu aceitasse esse pensamento limitado, a cooperativa perderia R$1,2B em receita até 2025 e ficaria presa ao rótulo de seguradora tradicional.`,
    t: `Tarefa — Minha função oficial era liderar estratégia competitiva, mas eu assumi integralmente a responsabilidade de redesenhar o posicionamento. Defini meta pessoal de lançar três verticais adjacentes em 18 meses, engajar 20% das vidas em dois ou mais serviços e elevar o NPS em 5 pontos, provando que a Unimed podia atuar como orquestradora de um ecossistema completo de saúde e bem-estar.`,
    a: `Ação — Atuei como owner único do diagnóstico ao go-to-market. Escrevi o Vision Doc “Unimed+” dimensionando TAM de R$36B para 2030 e modelando ARR incremental de R$420M em cinco anos. Para vencer o ceticismo do CFO (temia margin squeeze), rodei três cenários de payback e mostrei retorno em 19 meses com margem EBITDA 6pp acima do plano médico. O CMO questionou foco clínico; eu comissionei pesquisa com 4.800 famílias e demonstrei que telemedicina integrada a programas preventivos triplicava adesão. Capturei algoritmos de predição via licenciamento com duas healthtechs, negociei cláusulas de compartilhamento de dados e construí roadmap em três ondas: APS 360, marketplace de bem-estar e módulo Pet Saúde. Estruturei squad dedicado de 18 pessoas, instalei OKRs trimestrais (ex.: “10 mil vidas em APS com queda de sinistralidade >12%”) e criei HealthOps War Room diário com DORA adaptado. Cada release eu revisava pessoalmente compliance clínico, finanças e narrativa para o conselho.`,
    r: `Resultado — Em 24 meses lancei as três verticais originais e adicionei Clube de Empresas Saudáveis e Telepsicologia. O ecossistema ativou 420 mil vidas (25% da base elegível), churn caiu de 12,4% para 8,3% (-33%), NPS avançou de 58 para 66 (+8). Receita anualizada incremental chegou a R$312M (Pet Saúde R$96M, APS 360 R$118M, Bem-estar R$56M, Telepsicologia R$42M). O custo médico por vida recuou 9,7%; sinistralidade nas carteiras em APS diminuiu 14pp. No B2B, 310 empresas aderiram ao Clube em nove meses com ticket médio de R$29 por colaborador. A visão virou eixo oficial da estratégia 2025-2028, o conselho criou diretoria de Plataforma Digital e eu fui nomeado para liderá-la.`,
    l: `Lição — Pensar grande, para mim, é transformar ameaça existencial em plataforma sustentável. Ao ancorar ambição em métricas duras, enfrentar conflitos com dados e instalar mecanismos de governança, eu tirei a Unimed do ciclo defensivo e construí um ecossistema que gera margem e fideliza famílias. Hoje todo movimento estratégico que conduzo segue essa fórmula: tese ousada, números que sustentam a ousadia e mecanismos que tornam a escala inevitável.`
  },
  en: {
    s: `Situation — In 2021 I reviewed Unimed's churn curve and spotted a red flag: omnichannel customers were 2.4x more likely to migrate to full-service healthtechs. The board wanted promotional bundles on the legacy plan. I pushed back: if I accepted that narrow thinking, the cooperative would forfeit BRL 1.2B in revenue by 2025 and remain a traditional insurer.`,
    t: `Task — My formal role was leading competitive strategy, yet I took full ownership to redesign the positioning. I set a personal goal to launch three adjacent verticals in 18 months, engage 20% of members in two or more services, and raise NPS by five points—proving Unimed could orchestrate a full health and wellness ecosystem.`,
    a: `Action — I acted as the single-threaded owner from diagnosis to go-to-market. I wrote the “Unimed+” vision document sizing a BRL 36B TAM for 2030 and modeling BRL 420M ARR over five years. To neutralize the CFO's margin concerns I ran three payback scenarios and showed 19-month ROI with EBITDA six points above the medical plan. The Chief Medical Officer questioned clinical focus; I commissioned research with 4,800 families proving telemedicine integrated into prevention tripled adherence. I secured predictive algorithms from two healthtech partners, negotiated data-sharing clauses, and built a three-wave roadmap: APS 360, wellness marketplace, and Pet Health module. I assembled an 18-person squad, set quarterly OKRs (e.g., “10k lives in APS with >12% claims drop”), and created a daily HealthOps war room with adapted DORA metrics. Every release I personally reviewed clinical compliance, finance, and narrative for the board.`,
    r: `Result — Within 24 months I launched the three original verticals plus Healthy Companies Club and Telepsychology. The ecosystem activated 420k lives (25% of the eligible base), churn fell from 12.4% to 8.3% (-33%), and NPS climbed from 58 to 66 (+8). Annualized incremental revenue hit BRL 312M (Pet Health BRL 96M, APS 360 BRL 118M, Wellness BRL 56M, Telepsychology BRL 42M). Medical cost per life dropped 9.7%; claims in APS portfolios decreased 14pp. In B2B, 310 companies joined the Club within nine months at BRL 29 ARPU per employee. The vision became an official 2025-2028 strategic pillar and the board created a Digital Platform division, appointing me to lead it.`,
    l: `Learning — Thinking big for me is turning an existential threat into a sustainable platform. By anchoring ambition in hard metrics, facing conflicts with data, and installing governance mechanisms, I moved Unimed from a defensive posture to an ecosystem that generates margin and loyalty. Every strategic move I now drive follows that formula: bold thesis, numbers that sustain the boldness, and mechanisms that make scale inevitable.`
  },
  fups: [
    {
      q: "Quais dados convenceram o conselho de que o risco de perder R$1,2B era real?",
      a: "Eu cruzei churn por segmento com share digital, mostrei que cada ponto de churn equivalia a R$92M e modelei cenário em que healthtechs capturavam 15% da base, gerando perda acumulada de R$1,2B em quatro anos.",
      q_en: "Which data convinced the board the BRL 1.2B risk was real?",
      a_en: "I crossed churn by segment with digital share, showed each churn point meant BRL 92M, and modeled healthtechs capturing 15% of the base, creating a BRL 1.2B loss over four years."
    },
    {
      q: "Como você mediu o sucesso financeiro das verticais?",
      a: "Implementei cohort P&L mensal separando receita recorrente, CAC, sinistralidade e contribuição por vida. O painel mostrou payback médio de 11 meses e margem EBITDA consolidada de 23%.",
      q_en: "How did you measure financial success of the verticals?",
      a_en: "I built a monthly cohort P&L splitting recurring revenue, CAC, claims, and per-life contribution. The dashboard showed 11-month payback and 23% consolidated EBITDA margin."
    },
    {
      q: "Qual conflito com o CFO você precisou vencer?",
      a: "Ele travou CAPEX acima de R$40M. Respondi apresentando piloto APS com queda de sinistralidade de 12% em 90 dias, projetei economia anual de R$74M e criei gatilho de corte caso o ganho ficasse abaixo de 8%. O CAPEX foi liberado.",
      q_en: "What conflict with the CFO did you need to overcome?",
      a_en: "He froze CAPEX above BRL 40M. I presented the APS pilot with 12% claims reduction in 90 days, projected BRL 74M yearly savings, and added a kill trigger if the drop stayed under 8%. CAPEX was released."
    },
    {
      q: "Como garantiu aderência clínica na expansão?",
      a: "Criei conselho clínico com nove especialistas, defini standards assistenciais e KPIs de desfecho (HbA1c, IMC, saúde mental). Nenhuma feature ia ao ar sem parecer favorável e protocolo publicado.",
      q_en: "How did you ensure clinical adherence during expansion?",
      a_en: "I set up a nine-expert clinical board, defined care standards and outcome KPIs (HbA1c, BMI, mental health). No feature shipped without a favorable opinion and published protocol."
    },
    {
      q: "Quais mecanismos ligaram estratégia ao dia a dia?",
      a: "Instalei HealthOps War Room diário com DORA adaptado (lead time, change failure rate, adoção) e atrelei bônus variável a OKRs de adoção, impedindo que as áreas tratassem os produtos como side project.",
      q_en: "Which mechanisms linked strategy to daily execution?",
      a_en: "I ran a daily HealthOps war room with adapted DORA (lead time, change failure rate, adoption) and tied variable compensation to adoption OKRs, preventing teams from treating the products as side projects."
    },
    {
      q: "Como tratou risco de canibalizar o plano principal?",
      a: "Segmentei ofertas por persona, criei guardrails de pricing (serviços complementares só podiam substituir até 15% da mensalidade base) e proibi cross-sell compulsório, evitando dumping.",
      q_en: "How did you handle cannibalization risk on the core plan?",
      a_en: "I segmented offers by persona, set pricing guardrails (complementary services could replace only up to 15% of base premium), and banned compulsory cross-sell to avoid dumping."
    },
    {
      q: "Quais métricas de cliente mostraram ganho real?",
      a: "Além do NPS +8, monitorei Net Health Score (+11), tempo médio de atendimento em telemedicina (37 para 14 minutos) e satisfação em telepsicologia (4,8/5). Essas métricas entraram no scorecard trimestral.",
      q_en: "Which customer metrics showed real gains?",
      a_en: "Beyond the +8 NPS, I tracked Net Health Score (+11), telemedicine average response time (37 to 14 minutes), and telepsychology satisfaction (4.8/5). Those metrics fed the quarterly scorecard."
    },
    {
      q: "Como escalou cultura de plataforma dentro da cooperativa?",
      a: "Lancei o programa Plataforma Mindset com seis módulos e certificação. 1.480 colaboradores completaram a trilha e 73% dos squads adotaram métricas digitais de produto em seis meses.",
      q_en: "How did you scale platform culture inside the cooperative?",
      a_en: "I launched the Platform Mindset program with six modules and certification. 1,480 employees completed it and 73% of squads adopted digital product metrics within six months."
    },
    {
      q: "Que aprendizados tirou dos parceiros healthtechs?",
      a: "Negociei acesso a dados de engajamento, identifiquei padrões de nudges semanais e adaptei nossa régua. Isso elevou engajamento em APS 28% e reduziu faltas em consultas 19%.",
      q_en: "What did you learn from healthtech partners?",
      a_en: "I negotiated access to engagement data, identified weekly nudge patterns, and adapted our cadences. Engagement in APS rose 28% and missed appointments fell 19%."
    },
    {
      q: "Se pudesse acelerar ainda mais, o que faria diferente?",
      a: "Eu anteciparia a camada de APIs abertas. Construí no mês 16; se tivesse iniciado no mês 6, o time-to-market de parceiros teria reduzido 45 dias.",
      q_en: "If you could accelerate further, what would you do differently?",
      a_en: "I'd pull the open API layer forward. We built it in month 16; starting in month six would have shaved 45 days off partner time-to-market."
    }
  ]
};

export default case_2;
