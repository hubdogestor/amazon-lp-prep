// Configurações do LP - are_right_a_lot
const are_right_a_lot_config = {
  principle: {
    title: "Estar Certo, e muito",
    title_en: "Are Right, A Lot",
    description: `Os líderes estão certos na maioria das vezes. Eles têm bom julgamento e bons instintos. Eles buscam perspectivas diversas e trabalham para refutar suas próprias crenças.`,
    description_en: `Leaders are right a lot. They have strong judgment and good instincts. They seek diverse perspectives and work to disconfirm their beliefs.`,
    icon: "🎯"
  },
  id: "are_right_a_lot",
  name: "Estar Certo, e muito"
};

export default are_right_a_lot_config;
