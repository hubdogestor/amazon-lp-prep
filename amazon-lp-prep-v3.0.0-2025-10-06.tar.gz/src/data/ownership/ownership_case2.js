// Case 2 - ownership
const case_2 = {
  id: "sefaz-pmo-creation",
  title: "Estruturação do PMO Institucional e Governança do PROFISCO II do Zero",
  title_pt: "Estruturação do PMO Institucional e Governança do PROFISCO II do Zero",
  title_en: "Institutional PMO Structuring and PROFISCO II Governance from Scratch",
  company: "SEFAZ/RS",
  period: "08/2024-11/2025",
  isTopCase: false,
  isGoodCase: false,
  pt: {
    s: `Eu recebi um ofício do BID com alerta vermelho: se em 45 dias a SEFAZ/RS não apresentasse um plano robusto de governança para o PROFISCO II (R$ 180M), o desembolso de US$ 12M seria congelado. Eu enxergava a CAGE tocando 28 projetos críticos sem PMO, três iniciativas duplicadas queimando R$ 4,2M e 18 auditorias em atraso. Cada diretor dizia "isso é da outra secretaria" enquanto 42 mil contribuintes aguardavam melhorias em serviços digitais que nunca chegavam.`,
    t: `Meu contrato dizia suporte metodológico, mas eu me declarei owner único da governança. Eu assumi como metas zerar suspensão de desembolso, eliminar duplicidade, reduzir desvio de prazo de 23% para abaixo de 8% e entregar dashboards diários para secretários e BID. Eu prometi ao Secretário da Fazenda um blueprint em sete dias e rituais operando em 30 sem contratar consultoria externa.`,
    a: `Eu mergulhei em 11 bases (S2GPR, FPE, SEI, e-Social) no primeiro fim de semana e construí no Power BI um mapa dos 28 projetos com burn rate, entregáveis e impacto no contribuinte. Eu usei o mapa para derrubar a proposta de contratar consultoria de R$ 1,1M provando que 62% dos atrasos vinham da ausência de mecanismos internos. Em seguida: (1) Eu desenhei a governança em três loops — war room diário comigo, ritos quinzenais com secretários e steering mensal com o BID com pacote de métricas (NPS interno, savings, risco regulatório); (2) Eu escrevi 31 templates e automatizei 18 dashboards em SharePoint/Power BI, reduzindo coleta manual de seis horas para 40 minutos por projeto; (3) Eu implantei mecanismo de Customer Obsession entrevistando 37 auditores e 52 usuários fiscais, repriorizando backlog por impacto no cidadão e reescalando o portfólio; (4) Eu quebrei resistência de diretorias que alegavam burocracia facilitando workshops com dados — mostrar que fundir três projetos digitais em um liberaria R$ 1,8M e cortaria tempo de entrega ao contribuinte de 210 para 120 dias; (5) Eu abri linha direta com o BID enviando relatórios semanais com 16 KPIs, matriz de risco atualizada e registro de decisões, evitando três ofícios de não conformidade.`,
    r: `Eu vi o BID liberar integralmente os US$ 12M em 90 dias, sem retenções. Eu eliminei 100% das duplicidades, reduzi o desvio médio de prazo de 23% para 7,4% e recuperei R$ 2,3M do orçamento anual. Eu elevei o NPS dos serviços digitais para contribuintes de 52 para 76, reduzi o tempo de restituição prioritária de ICMS de 28 para nove dias e automatizei 72% dos reports, liberando 1.520 horas da equipe por ano. Eu capacitei oito servidores que se certificaram no PMI, assumiram o PMO e foram citados pelo BID como referência nacional.`,
    l: `Eu aprendi que ownership no setor público é provar que disciplina gera valor para o cidadão, não burocracia. Eu mostrei que combinar modelagem financeira, defesa do usuário final e mecanismos autoportantes dispensa consultorias e sustenta resultados. Eu transformei esse caso no meu template para programas financiados por organismos multilaterais.`,
  },
  en: {
    s: `I received an IDB red-alert letter: if SEFAZ/RS failed to deliver a robust governance plan for PROFISCO II (R$180M) within 45 days, a US$12M disbursement would be frozen. I saw CAGE running 28 critical projects with no PMO, three duplicated initiatives burning R$4.2M, and 18 audits overdue while 42K taxpayers awaited digital improvements that never arrived.`,
    t: `My contract said methodology support, but I declared myself the single-threaded owner. I set goals to avoid disbursement suspension, eliminate duplication, cut schedule deviation from 23% to below 8%, and deliver daily dashboards to the secretaries and IDB. I promised the Finance Secretary a blueprint in seven days and live rituals in 30 without hiring external consultants.`,
    a: `I dove into 11 systems (S2GPR, FPE, SEI, e-Social) the first weekend and built a Power BI map of the 28 projects with burn rate, deliverables, and taxpayer impact. I used the map to kill a R$1.1M consultancy pitch by proving 62% of delays came from missing internal mechanisms. Then I: (1) designed governance across three loops—daily war room with me, biweekly rituals with secretaries, and a monthly IDB steering with metrics (internal NPS, savings, regulatory risk); (2) authored 31 templates and automated 18 dashboards on SharePoint/Power BI, shrinking manual data gathering from six hours to 40 minutes per project; (3) launched a customer-obsession mechanism by interviewing 37 auditors and 52 tax service users, reprioritizing the backlog by taxpayer impact, and re-scoping the portfolio; (4) broke director resistance with data workshops showing that merging three digital projects into one freed R$1.8M and cut taxpayer lead time from 210 to 120 days; (5) opened a direct line with the IDB through weekly reports covering 16 KPIs, a refreshed risk matrix, and a decisions log, preventing three non-compliance notices.`,
    r: `Within 90 days the IDB released the entire US$12M tranche with no holds. I removed duplication, cut schedule deviation from 23% to 7.4%, recovered R$2.3M from the annual budget, lifted taxpayer-facing service NPS from 52 to 76, and reduced priority ICMS refund time from 28 to nine days. Automating 72% of reporting freed 1,520 staff hours per year, and the eight civil servants I trained earned PMI certifications, took over the PMO, and were cited by the IDB as a national reference.`,
    l: `I learned that public-sector ownership means proving discipline creates citizen value instead of bureaucracy. I showed that blending financial modeling, user advocacy, and self-sustaining mechanisms removes dependency on consultants and keeps results alive. I now treat this playbook as the blueprint for multilateral-funded transformations.`,
  },
  fups: [
    {
      "q": "Como estruturou o mapa unificado de projetos em tão pouco tempo?",
      "a": "Eu extraí dados de 11 sistemas, normalizei em Python (Pandas) e gerei um data mart no Power BI com dimensões de orçamento, cronograma e métricas de atendimento. Em três dias eu finalizei 18 visões e uma matriz de alinhamento com o BID que virou fonte oficial.",
      "q_en": "How did you build the unified project map so quickly?",
      "a_en": "I pulled data from 11 systems, normalized it in Python (Pandas), and built a Power BI data mart with budget, schedule, and service metrics. In three days I delivered 18 views plus an IDB alignment matrix that became the single source of truth."
    },
    {
      "q": "De que forma convenceu a alta gestão a não contratar a consultoria externa?",
      "a": "Eu apresentei business case mostrando que a consultoria custaria R$ 1,1M e exigiria 14 semanas de onboarding, enquanto meu plano interno removeria 62% dos gargalos em seis semanas. Eu garanti quick wins (dashboard em cinco dias, governança em 15) e alinhei risco com o BID.",
      "q_en": "How did you persuade leadership to avoid hiring the external consultancy?",
      "a_en": "I presented a business case showing the consultancy would cost R$1.1M with 14 weeks of onboarding, while my internal plan would remove 62% of bottlenecks in six weeks. I guaranteed quick wins (dashboard in five days, governance live in 15) and aligned risk with the IDB."
    },
    {
      "q": "Como mediu impacto no contribuinte para priorizar o backlog?",
      "a": "Eu cruzei NPS dos serviços, tempo de ciclo (ICMS, certidões) e volume de chamados da ouvidoria. Eu atribuí peso maior a serviços com NPS abaixo de 60 e impacto em arrecadação, orientando o sequenciamento das entregas e a revisão de escopos duplicados.",
      "q_en": "How did you quantify taxpayer impact to prioritize the backlog?",
      "a_en": "I combined service NPS, cycle time (ICMS refunds, certificates), and call-center volume, giving higher weight to services with NPS below 60 and revenue impact. That guided delivery sequencing and removal of duplicate scope."
    },
    {
      "q": "Quais indicadores você levou semanalmente para o BID?",
      "a": "Eu levei 16 KPIs em quatro grupos: execução (burn rate, earned value), compliance (auditorias atendidas, riscos críticos), cliente (NPS, backlog contribuinte) e capacidade (horas liberadas, maturidade de processos). Eu anexei sempre um plano de ações.",
      "q_en": "Which indicators did you report weekly to the IDB?",
      "a_en": "I reported 16 KPIs across four groups: execution (burn rate, earned value), compliance (audits served, critical risks), customer (NPS, taxpayer backlog), and capability (hours freed, process maturity), always attaching an action plan."
    },
    {
      "q": "Como venceu a resistência das diretorias que temiam burocracia?",
      "a": "Eu usei dados e facilitação: mapeei gargalos, apresentei trade-offs e deixei cada diretoria escolher indicadores chave. Eu co-liderei as primeiras execuções para provar ganhos; depois que viram R$ 1,8M liberados, a resistência desapareceu.",
      "q_en": "How did you overcome director resistance about added bureaucracy?",
      "a_en": "I used data and facilitation: mapped bottlenecks, presented trade-offs, and let each director choose key indicators. I co-led the first executions to prove the gains; once they saw R$1.8M freed, resistance disappeared."
    },
    {
      "q": "Que mecanismos garantiram que o time interno assumisse o PMO?",
      "a": "Eu implementei trilhas de capacitação (24 horas), plano de sombra em que cada servidor conduzia um rito comigo e mecanismo de certificação interna. Eu vinculei reconhecimento ao uso dos templates e criei comunidade de prática quinzenal. Em 60 dias a equipe conduzia os ritos sozinha.",
      "q_en": "Which mechanisms ensured the internal team took ownership of the PMO?",
      "a_en": "I set up a 24-hour training track, a shadowing plan where each civil servant ran a ritual with me, and an internal certification mechanism. I tied recognition to template usage and created a biweekly community of practice; within 60 days the team ran the rituals solo."
    },
    {
      "q": "Como mitigou riscos regulatórios durante a transformação?",
      "a": "Eu mantive uma matriz de risco viva com 18 itens críticos, defini gatilhos de contingência e reservei 12% da capacidade para ações corretivas. Quando o TCE solicitou auditoria surpresa, eu entreguei evidências em 48 horas.",
      "q_en": "How did you mitigate regulatory risks during the transformation?",
      "a_en": "I kept a living risk matrix with 18 critical items, set contingency triggers, and reserved 12% capacity for corrective actions. When the state audit court requested a surprise review, I delivered evidence within 48 hours."
    },
    {
      "q": "Qual foi o maior aprendizado com os usuários fiscais?",
      "a": "Eu descobri que o principal atrito era falta de previsibilidade na restituição de ICMS. Eu adiantei o novo motor de restituição em duas sprints e criei notificações semanais para contribuintes, elevando NPS para 76.",
      "q_en": "What was the biggest insight from taxpayer users?",
      "a_en": "I learned the core pain was lack of predictability on ICMS refunds. I moved the new refund engine two sprints earlier and introduced weekly notifications to taxpayers, lifting NPS to 76."
    },
    {
      "q": "Como esse modelo foi reaplicado no PROFISCO III?",
      "a": "Eu deixei blueprint com fases, indicadores e playbook de onboarding. No PROFISCO III eu repliquei os três loops de governança, adaptei KPIs para foco em analytics e garanti liberação inicial de R$ 20M sem ressalvas do BID.",
      "q_en": "How was this model reused in PROFISCO III?",
      "a_en": "I left a blueprint covering phases, indicators, and onboarding playbook. In PROFISCO III I replicated the three governance loops, tailored KPIs toward analytics, and secured the initial R$20M release with no IDB findings."
    },
    {
      "q": "Se rodasse o programa novamente, o que aceleraria?",
      "a": "Eu integraria analytics preditivo desde o dia um; no projeto original implantei alertas automáticos apenas no mês dois. Antecipando modelos de previsão, eu reduziria a necessidade de cortar escopo no fim.",
      "q_en": "If you ran the program again, what would you accelerate?",
      "a_en": "I would integrate predictive analytics from day one; in the original timeline automated alerts only arrived in month two. Anticipating forecasting models would reduce late scope cuts."
    }
  ]
};

export default case_2;
