// Case 3 - dive_deep
const case_3 = {
  id: "unimed-fraud-investigation",
  title: "Investigacao Manual de Anomalias em Reembolsos para Identificar Fraude em Rede",
  title_pt: "Investigacao Manual de Anomalias em Reembolsos para Identificar Fraude em Rede",
  title_en: "Manual Investigation of Reimbursement Anomalies to Uncover Network Fraud",
  company: "Unimed",
  period: "06/2022-12/2022",
  isTopCase: false,
  isGoodCase: true,
  pt: {
    s: `No segundo semestre de 2022 eu liderava a celula de analytics antifraude da Unimed. As perdas totais estavam dentro do limite (0,5% da sinistralidade), mas uma analista experiente me sinalizou que pacientes de uma rede popular recebiam muitos reembolsos de baixo valor durante a madrugada. O dashboard padrao nao mostrava nada e o diretor assistencial queria seguir com outras prioridades. O alerta podia ser um "falso positivo", mas se fosse real significaria reembolsos indevidos atingindo clientes com franquias altas.`,
    t: `Assumi ownership total do caso. Eu prometi a CFO entregar em cinco dias um veredito com quantificacao financeira, impacto ao cliente e plano de bloqueio. Ao mesmo tempo convenci o diretor assistencial a liberar acesso completo aos logs e a permitir contato com regulatorio e Ouvidoria para entender possiveis queixas dos beneficiarios.`,
    a: `No dia 1 eu reuni dados brutos: pedi ao time de TI um dump de 186 mil transacoes (47 MB), carreguei no Power BI e criei oito visualizacoes exploratorias (scatter valor x hora, heatmap IP x procedimento, grafo medico-paciente, timeline por dia da semana, mapa CEP, frequencia de procedimentos, boxplot por medico e matriz de correlacao). O scatter mostrou um cluster anormal entre 2h e 4h com valores R$ 50-R$ 150 e o mesmo IP repetido. Para colocar o cliente no centro, consultei a Ouvidoria: havia 27 reclamacoes recentes sobre reembolsos aprovados "sem atendimento". Liguei para tres beneficiarios e todos confirmaram que nao tinham ido as clinicas. No dia 2 eu confrontei o diretor assistencial, que temia questionar uma rede parceira. Mostrei a matriz medico-paciente e projetei o impacto: R$ 2,1M/ano em perdas, queda de 6 pontos no NPS e risco de sancao da ANS. Ele aprovou meu plano. Nos dias seguintes coordenei uma forca-tarefa: bloqueei CPFs e IPs suspeitos, desenhei com ciencia de dados novas features (contador de pacientes por IP/hora, score de horario critico, flag de rede artificial), criei war room semanal com atendimento/juridico/compliance para resolver incidentes em ate 24h e treinei a analista que trouxe o alerta para replicar a metodologia.`,
    r: `Em 30 dias reduzimos em 95% os reembolsos suspeitos (de R$ 175K/mes para R$ 8K). No ano isso evitou R$ 2,1M em perdas, equivalente a 15% da linha total de fraudes. Comunicamos proativamente os 112 beneficiarios; 89 responderam e elogiaram o estorno imediato (CSAT 4,7/5). Instalamos o modelo com as features que defini e configuramos alertas diarios: qualquer IP acima de tres pacientes em 24h gera incidente. O NPS permaneceu em 78 (versus 72 projetado sem acao) e a ANS aprovou nossa auditoria sem ressalvas.`,
    l: `Aprendi que intuicao humana somada a exploracao visual profunda encontra padroes que modelos supervisionados ainda nao veem. Desde entao mantenho tres mecanismos: 1) ritual semanal de revisao de outliers com analistas, 2) playbook de investigacao com oito visualizacoes e contato direto com clientes, 3) governanca de resposta rapida com war room multifuncional. Em pagamentos digitais aplico o mesmo metodo para fraudes "low & slow": se alguem diz que algo parece estranho, eu mergulho fundo antes que vire manchete.`
  },
  en: {
    s: `In H2 2022 I led Unimed's antifraud analytics pod. Losses were within target (0.5% of claims), but a senior analyst flagged several low-value reimbursements hitting a partner network at night. Dashboards showed nothing and the medical director wanted to move on. Her instinct might have been a false alarm, yet if true we were reimbursing procedures never performed for customers with higher deductibles.`,
    t: `I took full ownership. I promised the CFO a five-day verdict quantifying financial exposure, customer impact, and a blocking plan. At the same time I convinced the medical director to grant full log access and let me engage regulatory and Customer Care to capture beneficiary complaints.`,
    a: `Day 1 I grabbed raw data: requested a six-month dump (186K transactions, 47 MB), loaded it into Power BI, and built eight exploratory views (value-hour scatter, IP-procedure heatmap, doctor-patient graph, weekday timeline, ZIP map, procedure frequency, doctor boxplots, correlation matrix). The scatter revealed a 2-4 a.m. cluster with R$50-150 values and a recurring IP. To inject customer voice I pulled 27 complaints from Customer Care and called three beneficiaries-all denied visiting the clinics. Day 2 I faced the medical director, who feared accusing a partner. I showed the relationship graph and the projected impact: R$2.1M/year losses, six-point NPS drop, ANS risk. He approved my plan. I then led a task force: blocked suspicious CPFs/IPs, designed new model features with data science (patients-per-IP counter, critical-hour score, artificial-network flag), created a weekly war room with service/legal/compliance to close incidents within 24h, and coached the analyst who raised the flag so she could replicate the methodology.`,
    r: `Within 30 days suspicious reimbursements fell 95% (R$175K to R$8K per month). Annually that avoided R$2.1M-15% of total fraud losses. We contacted the 112 impacted beneficiaries; 89 replied and praised the immediate refunds (CSAT 4.7/5). The enhanced model with my features went live with daily alerts, flagging any IP serving more than three patients in 24h. Customer NPS held at 78 (instead of dropping to 72) and ANS cleared our audit with zero findings.`,
    l: `I learned that human intuition plus visual deep dives exposes patterns supervised models have not learned. I now keep three mechanisms: 1) a weekly outlier review with analysts, 2) an investigation playbook with the same eight visuals plus direct customer contact, and 3) a rapid-response war room across functions. In digital payments I apply the same low-and-slow playbook-whenever someone says "this feels off," I dive deep before it becomes tomorrow's headline.`
  },
  fups: [
    {
      q: "Como voce tratou a resistencia do diretor assistencial em apontar uma rede parceira?",
      a: "Levei dados incontestaveis: mapa medico-paciente, projecao de perda e risco regulatorio. Propus comunicacao discreta e conjunta em vez de exposicao publica. Assim ele se sentiu protegido e liberou meus passos.",
      q_en: "How did you address the medical director's resistance to questioning a partner network?",
      a_en: "I brought irrefutable data: the doctor-patient map, loss projection, and regulatory risk. I suggested a discreet joint outreach instead of public blame, giving him air cover to approve the plan." 
    },
    {
      q: "Quais indicadores voce monitorou para provar impacto ao cliente?",
      a: "Combinei volume suspeito, CSAT dos 112 clientes, NPS da carteira e numero de reclamacoes na ouvidoria. Isso traduziu o problema em termos de experiencia e nao apenas financas.",
      q_en: "Which indicators did you track to prove customer impact?",
      a_en: "I combined suspicious volume, CSAT for the 112 customers, portfolio NPS, and ombudsman complaints. That framed the issue in customer terms, not just finance." 
    },
    {
      q: "Como garantiu que o modelo atualizado detectasse fraudes futuras similares?",
      a: "Criei tres novas features, defini limiares de alerta e exigi testes A/B com base historica. Tambem agendei revisao mensal de performance com ciencia de dados e atendimento.",
      q_en: "How did you ensure the updated model would catch similar fraud going forward?",
      a_en: "I delivered three new features, defined alert thresholds, and required A/B tests on historical data. I also scheduled a monthly performance review with data science and service teams." 
    },
    {
      q: "Qual foi a logica por tras do bloqueio temporario de CPFs/IPs?",
      a: "Usei um score com frequencia por hora, valor acumulado e repeticao de procedimentos. Bloqueei quem passava do percentil 99 e defini revisao manual em 24h para evitar falso positivo.",
      q_en: "What logic did you apply to temporarily block CPFs/IPs?",
      a_en: "I built a score combining hourly frequency, accumulated value, and repeated procedures. Anything above the 99th percentile was blocked and manually reviewed within 24 hours to avoid false positives." 
    },
    {
      q: "Como voce reconheceu o alerta inicial da analista?",
      a: "Reconheci publicamente no all-hands, criei um canal de dicas de fraude e inclui a analista na definicao dos novos mecanismos. Isso incentivou o time a compartilhar sinais cedo.",
      q_en: "How did you recognize the analyst's initial alert?",
      a_en: "I celebrated her in the all-hands, opened a fraud-tip channel, and involved her in defining the new mechanisms. That encouraged the team to raise signals early." 
    },
    {
      q: "Que metricas mostraram que o war room semanal era efetivo?",
      a: "Tempo medio de resposta caiu de 5 dias para 18 horas, reincidencia ficou zero e 100% dos casos tinham plano fechado ate o proximo encontro.",
      q_en: "Which metrics showed the weekly war room was effective?",
      a_en: "Average response time dropped from five days to 18 hours, recidivism hit zero, and 100% of cases had a closed plan by the next meeting." 
    },
    {
      q: "Como voce assegurou compliance com ANS ao bloquear reembolsos?",
      a: "Alinhei com juridico um procedimento: bloqueio preventivo, contato ao beneficiario em 24h, documentacao completa no prontuario digital. Isso manteve aderencia e evitou reclamacoes.",
      q_en: "How did you ensure ANS compliance when blocking reimbursements?",
      a_en: "I aligned with legal on a procedure: preventive block, beneficiary contact within 24 hours, full documentation in the digital record. That kept us compliant and avoided complaints." 
    },
    {
      q: "Qual visualizacao foi decisiva e por que?",
      a: "O scatter valor x hora expos o cluster improvavel. Ele mostrava um padrao que nenhum relatorio tabular revelaria e foi a prova-chave para convencer executivos.",
      q_en: "Which visualization was decisive and why?",
      a_en: "The value-hour scatter exposed the unlikely cluster. It revealed a pattern no tabular report would highlight and became the key evidence for executives." 
    },
    {
      q: "Como a metodologia foi replicada em outros produtos?",
      a: "Levei o mesmo playbook para o Sicredi e reduzi fraude PIX em 45% usando as mesmas oito visualizacoes e o ritual de outliers.",
      q_en: "How was the methodology replicated elsewhere?",
      a_en: "I reused the playbook at Sicredi and cut PIX fraud by 45% using the same eight visualizations and outlier ritual." 
    },
    {
      q: "Qual licao voce da para times de dados sobre intuicao humana?",
      a: "Tratem intuicao como sinal prioritario. Criei um mecanismo: qualquer analista abre um 'case de intuicao' e eu garanto slot de investigacao em 48h. Isso mantem o loop humano + maquina.",
      q_en: "What lesson do you give data teams about human intuition?",
      a_en: "Treat intuition as a priority signal. I codified it: any analyst can open an 'intuition case' and I guarantee an investigation slot within 48 hours. That keeps the human + machine loop healthy." 
    }
  ]
};

export default case_3;


