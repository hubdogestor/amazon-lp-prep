// Case 4 - dive_deep
const case_4 = {
  id: "sicredi-pix-settlement",
  title: "Reducao de 47% no Tempo de Liquidacao de Pagamentos PIX",
  title_pt: "Reducao de 47% no Tempo de Liquidacao de Pagamentos PIX",
  title_en: "47% Reduction in PIX Payment Settlement Time",
  company: "Sicredi",
  period: "03/2020-08/2020",
  isTopCase: false,
  isGoodCase: false,
  pt: {
    s: `Em 2020 eu liderava o produto PIX no Sicredi quando o SLA desabou: liquidacao media de 4,2h versus 3h exigidas pelo Bacen. Um merchant de R$2M/mensais anunciou que migraria para a concorrencia, o NPS caiu para 32 e recebemos carta oficial avisando de multas entre R$50k e R$200k por incidente se nada mudasse em 60 dias. Fraude, TI e Operacoes estavam em conflito e ninguem tinha plano concreto.`,
    t: `Assumi ownership total. Prometi ao COO e ao Bacen reduzir o tempo medio para abaixo de 2h em 45 dias (margem adicional para absorver picos) e, ao mesmo tempo, preservar a experiencia do cliente mantendo falsos positivos abaixo de 0,5%. Eu seria responsavel por diagnostico, mudanca tecnica e mecanismos de monitoramento.`,
    a: `Nos primeiros dois dias tracei o fluxo ponta a ponta: 15 sistemas, sete integracoes, logs fragmentados. Instrumentei cada etapa com timestamps proprios e escrevi 47 consultas SQL para medir fila e throughput. Descobri que 65% do tempo total estava preso em uma unica fila sequencial do motor de fraude (p95 = 192 minutos) que nao aparecia em nenhum dashboard. Confrontei o diretor de Fraude que sugeria apenas "mais servidores" e provei com dados que o gargalo era arquitetural. Eu desenhei um modelo de risk scoring com tres esteiras paralelas (fast 80%, medium 15%, high 5%), extraindo 300k transacoes historicas, criando 87k features e treinando regressao logistica (accuracy 94,7%, recall high-risk 91%). Em uma semana subi um POC em staging, rodei 50k transacoes anonimizadas e o tempo medio caiu para 1,8h no simulador. Entreguei diagramas, pseudocodigo e estimativa de infraestrutura para conquistar o apoio de TI, organizei um war room diario com engenharia/fraude/operacoes, repriorizei backlog cortando itens nao criticos e configurei Grafana com 10 metricas, alertas no meu celular e runbook "SLA strike".`,
    r: `Em 38 dias o tempo medio caiu para 2,2h (-47%), p50 para 1,8h (-57%) e p95 para 2,9h (-31%). Evitamos multas, preservamos R$5,4M em receita de merchants estrategicos, churn de comerciantes caiu 18% e o NPS subiu de 32 para 68. A taxa de falsos positivos permaneceu em 0,4%. O modelo e os alertas viraram mecanismo padrao: qualquer fila acima de 120 minutos abre incidente com SLA de 2h.`,
    l: `Aprendi que pressao regulatoria so se resolve com conflito convertido em mecanismo. Agora, sempre que uma metrica critica sai do limite, eu reconstruo o fluxo com dados proprios, exponho o conflito com numeros e deixo alertas e runbooks ativos antes de encerrar. Isso protege o cliente e evita recidiva.`
  },
  en: {
    s: `In 2020 I led Sicredi's PIX product when the SLA imploded: average settlement took 4.2 hours while BACEN required 3. A R$2M/month merchant announced he would switch providers, settlement NPS fell to 32, and BACEN sent a formal letter warning of R$50K-200K fines per incident within 60 days. Fraud, IT, and Ops were fighting with no plan.`,
    t: `I took full ownership. I committed to the COO and BACEN to bring average settlement below two hours in 45 days, keeping the false-positive rate under 0.5%. I also set a stretch target of 45 days (not the 60 requested) to build buffer against future peaks. I owned the root-cause hunt, the technical delivery, and the monitoring mechanisms.`,
    a: `In the first two days I mapped the end-to-end flow: 15 systems, seven integrations, scattered logs. I instrumented every hop with timestamps and wrote 47 SQL queries to measure queues and throughput. I discovered that 65% of total latency sat in a sequential fraud queue (p95 = 192 minutes) no dashboard exposed. I challenged the fraud director who wanted "more servers" and proved with data that the bottleneck was architectural. I designed a risk-scoring model with three parallel lanes (fast 80%, medium 15%, high 5%), extracting 300K historical transactions, generating 87K features, and training logistic regression (94.7% accuracy, 91% high-risk recall). Within a week I deployed a staging POC, ran 50K anonymized real transactions, and the simulated average dropped to 1.8h. I provided architecture diagrams, pseudocode, and infra sizing to win IT buy-in, ran a daily war room with engineering/fraud/ops, re-prioritized the backlog cutting non-critical work, and set up Grafana with 10 metrics, on-call alerts, and an "SLA strike" runbook.`,
    r: `In 38 days we reduced average settlement to 2.2h (-47%), P50 to 1.8h (-57%), and P95 to 2.9h (-31%). We avoided fines, preserved R$5.4M from strategic merchants, merchant churn dropped 18%, and settlement NPS jumped from 32 to 68. The false-positive rate stayed at 0.4%. The model plus alerts became the standard mechanism: any queue above 120 minutes raises an incident with a two-hour SLA.`,
    l: `I learned that regulatory pressure only disappears when you convert conflict into mechanisms. Whenever a critical metric drifts now, I rebuild the flow with my own data, surface the disagreement with numbers, and leave alerts and runbooks running before closing the case. That keeps the customer safe and prevents recurrence.`
  },
  fups: [
    {
      q: "Como voce convenceu o diretor de Fraude a aceitar a nova arquitetura?",
      a: "Mostrei o funil com 65% da latencia na fila sequencial e apresentei arquitetura, riscos e rollback. Fiquei claro que mais servidores nao resolveriam o problema.",
      q_en: "How did you convince the fraud director to adopt the new architecture?",
      a_en: "I showed the funnel with 65% of latency in the sequential queue and presented architecture, risk, and rollback plans. It was clear more servers would not fix it." 
    },
    {
      q: "Quais metricas voce monitora hoje para garantir que o SLA nao volte a estourar?",
      a: "P50, p95, backlog de fila, taxa de falsos positivos e alertas para filas acima de 120 minutos. Cada alerta abre incidente com SLA de 2h.",
      q_en: "Which metrics do you monitor today to keep the SLA healthy?",
      a_en: "P50, P95, queue backlog, false-positive rate, and alerts whenever a queue exceeds 120 minutes. Each alert triggers a two-hour SLA incident." 
    },
    {
      q: "Como voce garantiu que o novo modelo nao aumentasse falsos positivos?",
      a: "Balanceei o dataset, monitorei precision/recall, rodei shadow mode por 10 dias e so promovi quando falsos positivos ficaram abaixo de 0,5%.",
      q_en: "How did you ensure the new model did not increase false positives?",
      a_en: "I balanced the dataset, tracked precision/recall, ran 10 days in shadow mode, and only promoted when false positives stayed below 0.5%." 
    },
    {
      q: "Qual foi o plano de comunicacao com merchants criticos?",
      a: "Contato proativo com os 50 maiores, explicacao do novo SLA, canal VIP e follow-up semanal ate NPS superar 60.",
      q_en: "What communication plan did you adopt with critical merchants?",
      a_en: "Proactive outreach to the top 50 merchants, explanation of the new SLA, a VIP channel, and weekly follow-ups until NPS stayed above 60." 
    },
    {
      q: "Como voce priorizou backlog sem prejudicar outras frentes?",
      a: "Mapeei OKRs, pausei itens nao criticos, negociei com marketing e compliance e mostrei o custo de inercia (multas + churn). Consegui squad dedicado por 45 dias.",
      q_en: "How did you prioritize the backlog without hurting other workstreams?",
      a_en: "I mapped OKRs, paused non-critical items, negotiated with marketing and compliance, and showed the cost of inaction (fines + churn). I secured a dedicated squad for 45 days." 
    },
    {
      q: "Quais testes voce executou antes do rollout final?",
      a: "POC em staging com 50k transacoes, A/B controlado em 10% do volume e monitoramento ao vivo por 48h antes do rollout total.",
      q_en: "What tests did you run before the full rollout?",
      a_en: "Staging POC with 50K transactions, a controlled A/B on 10% of traffic, and live monitoring for 48 hours before full rollout." 
    },
    {
      q: "Como voce protegeu a experiencia dos clientes classificados como alto risco?",
      a: "Mantive fallback manual com SLA de 2h e scripts de atendimento dedicados para merchants premium, garantindo transparencia sem atritos.",
      q_en: "How did you protect the experience of high-risk customers?",
      a_en: "I kept a manual fallback with a two-hour SLA and dedicated support scripts for premium merchants, ensuring transparency without friction." 
    },
    {
      q: "Que mecanismo impede novas mudancas de degradarem o SLA?",
      a: "Toda mudanca passa por teste de carga, comparacao de p95 e aprovacao minha + CTO antes do deploy. Alertas monitoram cada release por 48h.",
      q_en: "What mechanism keeps future changes from degrading the SLA?",
      a_en: "Every change goes through load testing, P95 comparison, and my + CTO approval before deployment. Alerts monitor each release for 48 hours." 
    },
    {
      q: "Como voce reaproveitou o aprendizado em outros fluxos?",
      a: "Documentei o playbook e repliquei em TED e boleto, reduzindo o tempo medio em 28% em 90 dias.",
      q_en: "How did you reuse the learning in other flows?",
      a_en: "I documented the playbook and replicated it for wire transfers and boleto, cutting average time by 28% within 90 days." 
    },
    {
      q: "Qual a principal licao que voce leva para entrevistas da Amazon?",
      a: "Converter conflito em mecanismo se tornou regra. Quando um SLA esta em risco, eu controlo o fluxo, convenco com dados e deixo alertas e runbooks em producao para evitar regressao.",
      q_en: "What is the key lesson you bring to Amazon interviews?",
      a_en: "Turning conflict into mechanisms is non-negotiable. When an SLA is at risk I control the flow, convince with data, and leave alerts and runbooks in production to prevent regression." 
    }
  ]
};

export default case_4;







