// Case 1 - dive_deep
const case_1 = {
  id: "sicredi-churn-analysis",
  title: "Analise de Dados para Identificar os Principais Drivers de Churn no App",
  title_pt: "Analise de Dados para Identificar os Principais Drivers de Churn no App",
  title_en: "Data Analysis to Identify Main App Churn Drivers",
  company: "Sicredi Woop",
  period: "01/2019-10/2019",
  isTopCase: true,
  isGoodCase: false,
  pt: {
    s: `Em 2019 eu era Estrategista de Produtos do banco digital Woop (Sicredi) e encontrei um cenario critico: churn anual de 40%, R$ 12M em receita perdida e pressao para investir R$ 400k em cashback. Eu enxerguei um risco direto aos 150% de crescimento que a diretoria cobrava e assumi que, se aceitasse o atalho, colocaria o cliente e a meta em perigo.`,
    t: `Eu me comprometi com o COO a entregar, em duas semanas, um diagnostico raiz, um business case com ROI e um plano com mecanismos. Eu seria accountable por provar se o churn vinha de falhas operacionais e por convencer a lideranca a priorizar o cliente em vez de beneficios superficiais.`,
    a: `Eu auditava dados usando minhas proprias consultas: pedi acesso direto ao Redshift, escrevi 47 queries cruzando cinco tabelas e reconstrui a jornada de 2,3M registros. Eu identifiquei que 54% dos cancelamentos aconteciam dentro dos primeiros sete dias e que 40% dos usuarios abandonavam o upload de documentos. Eu li 500 tickets e reviews, liguei para tres clientes afetados e confirmei o incomodo com mensagens confusas. Com esse material, eu confrontei o diretor comercial que defendia o cashback: demonstrei o funil passo a passo, projetei que resolver o onboarding (R$ 180k, 2 meses) tinha ROI 3x maior e solicitei o compromisso dele por escrito. Em paralelo, eu instalei um war room diario com engenharia e QA, defini metricas de sucesso (upload >95%, tempo <30s, falsos positivos <2%), pilotei com 10% da base e so escalei apos sete dias dentro do target. Para garantir perenidade, eu criei um dashboard de saude com oito metricas e alertas automaticos via e-mail/Slack.`,
    r: `Em nove meses o churn caiu de 40% para 32,8% (-18%) gracas ao plano que eu conduzi, preservando R$ 5,4M em receita anual. A conversao do onboarding subiu 20 p.p. e a base ativa cresceu 25%, permitindo alcancar a meta de 150% sem cashback. O war room virou cadencia quinzenal e reduziu o tempo de resposta a incidentes em 35%, evitando regresoes.`,
    l: `Eu aprendi que, sob pressao, desconfiar de narrativas simples salva o cliente. A tensao com o diretor comercial mostrou que dados estruturados quebram opinioes. Desde entao eu aplico tres mecanismos sistematicamente: 1) triangulo quantitativo + qualitativo + operacional, 2) levo conflitos explicitos as revisoes executivas e 3) monitoro continuamente com alertas automaticos. E assim que entrego decisoes rapidas sem sacrificar profundidade.`
  },
  en: {
    s: `In 2019 I served as Product Strategist for Woop, Sicredi's digital bank, and walked into a crisis: churn at 40%, R$12M in lost revenue, and pressure to spend R$400K on cashback. I saw that shortcut hurting customers and the 150% growth target, so I owned the problem.` ,
    t: `I committed to the COO that within two weeks I would deliver a root-cause diagnosis, an ROI-backed business case, and a mechanism-rich execution plan. I was accountable for proving churn was operational and for steering leadership toward a customer-first fix.` ,
    a: `I audited the data myself: requested direct Redshift access, wrote 47 cross-table queries, and rebuilt 2.3M user journeys. I found 54% of churn happening within seven days and 40% of users dropping in document upload. I read 500 tickets, called three affected customers, and confirmed messaging pain. Armed with that evidence I confronted the commercial director, presented step-by-step funnel data, compared three options (cashback R$400K, new feature R$650K, onboarding fix R$180K), and secured a written commitment for the fix. I set up a daily war room with engineering/QA, defined success metrics (upload >95%, average time <30s, false positives <2%), piloted with 10% of users, and only rolled out after seven on-target days. I also created an onboarding health dashboard with eight metrics and automated email/Slack alerts.` ,
    r: `Nine months later churn dropped from 40% to 32.8% (-18%) under the plan I led, preserving R$5.4M in annual revenue. Onboarding conversion jumped 20 percentage points and the active base grew 25%, hitting the 150% goal with zero cashback. The war room became a biweekly ritual, cutting incident response time by 35% and preventing regression.` ,
    l: `I learned that in high-pressure situations the safest path is to challenge easy narratives with raw data. The clash with the commercial director proved structured evidence resolves conflict quickly. Since then I always 1) triangulate quantitative, qualitative, and operational signals, 2) surface disagreements openly in exec reviews, and 3) run continuous monitoring with automated alerts. That is how I deliver speed without losing depth.`
  },
  fups: [
    {
      q: "Como voce conduziu o confronto com o diretor comercial e garantiu alinhamento sem desgastar a relacao?",
      a: "Preparei um doc de 8 paginas com dados e simulacoes, marquei uma sessao 1:1, mostrei o impacto financeiro de cada alternativa e pedi um commitment explicito. Transformei a discordancia em uma decisao baseada em ROI, o que facilitou o patrocinio dele na execucao.",
      q_en: "How did you handle the confrontation with the commercial director and secure alignment without damaging the relationship?",
      a_en: "I prepared an eight-page brief with data and simulations, set up a 1:1, showed the financial impact of each path, and asked for explicit commitment. Turning the disagreement into an ROI discussion made it easy for him to sponsor the execution." 
    },
    {
      q: "Quais controles voce implementou para evitar regressao apos o rollout do novo onboarding?",
      a: "Implementei alertas de anomalia via CloudWatch + Slack, uma cadencia quinzenal de auditoria com engenharia e um review mensal de coorte comigo e com o COO. Cada alerta abre automaticamente um ticket JIRA com SLA de 24h.",
      q_en: "What controls did you put in place to prevent regression after the new onboarding went live?",
      a_en: "I set up CloudWatch + Slack anomaly alerts, a biweekly audit with engineering, and a monthly cohort review with the COO. Each alert automatically opens a JIRA ticket with a 24-hour SLA." 
    },
    {
      q: "Como voce garantiu a consistencia dos dados entre Redshift, Firebase e tickets de suporte?",
      a: "Criei uma camada de staging com chaves unicas (user_id + timestamp) e escrevi scripts de reconciliacao em Python para comparar agregados. Se algum delta passava de 2%, o script travava a execucao e disparava alerta.",
      q_en: "How did you ensure data consistency among Redshift, Firebase, and support tickets?",
      a_en: "I created a staging layer with unique keys (user_id + timestamp) and built Python reconciliation scripts to compare aggregates. If any delta exceeded 2%, the script stopped and triggered an alert." 
    },
    {
      q: "Que trade-offs voce avaliou antes de priorizar o conserto do onboarding em vez de novos beneficios?",
      a: "Comparei tres opcoes: cashback (R$ 400k, impacto incerto), nova feature (R$ 650k, 6 meses) e correcao do onboarding (R$ 180k, 2 meses). Usei payback, NPV e risco de execucao para demonstrar que quitar a dor raiz tinha ROI e velocidade muito superiores.",
      q_en: "What trade-offs did you weigh before prioritizing the onboarding fix over new perks?",
      a_en: "I compared three options: cashback (R$400K, uncertain impact), new feature (R$650K, six months), and onboarding fix (R$180K, two months). I used payback, NPV, and execution risk to show the root-cause fix had superior ROI and speed." 
    },
    {
      q: "Quais foram os principais riscos do war room diario e como voce os mitigou?",
      a: "O principal risco era sobrecarregar engenharia e perder foco. Estabeleci agenda de 30 minutos, usei um kanban com tres prioridades e qualquer item fora do escopo exigia aprovacao minha + CTO. Tambem programei 'dias sem reuniao' para evitar fadiga.",
      q_en: "What were the main risks of the daily war room and how did you mitigate them?",
      a_en: "The main risk was overloading engineering and losing focus. I enforced a 30-minute agenda, used a three-priority kanban, and anything outside scope needed my + CTO approval. I also scheduled 'no-meeting days' to avoid fatigue." 
    },
    {
      q: "Como voce calculou e comunicou o ROI de 3x para a diretoria?",
      a: "Projetei receita preservada com base na reducao de churn (% x base x ticket medio) e comparei com o investimento incremental (OCR, UX, QA). Usei cenario conservador e mostrei payback em cinco meses. O CFO validou os numeros antes da apresentacao ao board.",
      q_en: "How did you calculate and communicate the 3x ROI to the board?",
      a_en: "I projected preserved revenue using churn reduction (% x base x ARPU) and compared it with incremental spend (OCR, UX, QA). I used a conservative scenario and showed five-month payback. The CFO validated the numbers before I presented to the board." 
    },
    {
      q: "De que forma voce garantiu que a solucao atendesse clientes com baixa proficiencia digital?",
      a: "Inclui no piloto um grupo de clientes 60+ e facilitei sessoes de usabilidade remota. Ajustei as mensagens para linguagem simples, inclui video microlearning e medi CSAT especifico desse publico, que subiu de 6,1 para 7,8.",
      q_en: "How did you make sure the solution worked for low digital literacy customers?",
      a_en: "I included 60+ customers in the pilot and ran remote usability sessions. I simplified error messages, added a microlearning video, and tracked a dedicated CSAT which climbed from 6.1 to 7.8." 
    },
    {
      q: "Como voce usou o aprendizado desse caso em outras frentes do Sicredi?",
      a: "Transformei a abordagem em training: formei seis PMs na metodologia de triangulacao, documentei o playbook e implementei retro trimestral. Aplicamos depois em credito, cartoes e investimentos, sempre com analise coorte + funil + qualitativo.",
      q_en: "How did you reuse this learning across other Sicredi initiatives?",
      a_en: "I turned the approach into training: coached six PMs on triangulation, documented the playbook, and instituted a quarterly retro. We reused it for lending, cards, and investments with the same cohort + funnel + qualitative triad." 
    },
    {
      q: "Qual metrica voce monitorou para provar que o problema nao voltou apos 12 meses?",
      a: "Alem do churn anualizado, monitorei a retencao de 7 e 30 dias por coorte. Se qualquer coorte caisse 5 p.p., o alerta automatico me obrigava a fazer deep dive e apresentar plano corretivo em 48h para o COO.",
      q_en: "Which metric did you monitor to prove the issue didn't return after 12 months?",
      a_en: "Beyond annual churn, I tracked seven-day and 30-day retention by cohort. If any cohort dropped 5 p.p., the automated alert forced a deep dive and a 48-hour corrective plan for the COO." 
    },
    {
      q: "Que licao voce leva para entrevistas da Amazon a partir desse conflito interno?",
      a: "Ser vocalmente autocritico e chegar com dados antes da discussao virar opiniao. Hoje preparo mecanismos, visualizacoes e ROI antes de entrar em qualquer debate de priorizacao - isso cria alinhamento rapido e evita guerras politicas.",
      q_en: "What's the key lesson from this internal conflict that you bring to Amazon interviews?",
      a_en: "Being vocally self-critical and arriving with data before opinions harden. I now prepare mechanisms, visuals, and ROI evidence before any prioritization debate-that creates fast alignment and avoids political battles." 
    }
  ]
};

export default case_1;

