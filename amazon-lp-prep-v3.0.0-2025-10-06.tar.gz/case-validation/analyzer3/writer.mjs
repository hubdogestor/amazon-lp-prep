export async function writeCaseFile(/* targetPath, obj */) {
  // intentionally disabled
}