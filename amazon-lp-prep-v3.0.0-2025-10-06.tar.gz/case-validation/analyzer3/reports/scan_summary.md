# scan_summary.md
Gerado em: 2025-10-06T12:25:18.365Z

- Casos avaliados: 1
- Ready: 1 | Needs-Polish: 0 | Needs-Rewrite: 0 | KO: 0 | Lint blockers: 0
- Score mÃ©dio: 100.0
- MÃ©tricas por case (mÃ©dia): 49.0
- Ratio EU:NÃ“S mÃ©dio: 1.00
- Bias signals (media): 2.0
- Dealbreakers totais: 0
- Warnings totais: 1
